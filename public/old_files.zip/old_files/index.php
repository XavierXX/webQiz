<?php
/**
 * My new Zend Framework Project
 * 
 * @author  
 * @version 
 */
require '../application/bootstrap.php'; 
